# Final-Project-Placement-Management-System
Spring Boot Project
Placement Management Application have Admin,Student,Placement,College entities.Admin entity is for login purpose and have a home page to connect with other entities.Placement,college,student entities have CRUD operation for create,delete ,update and read the details.Datas were stored in MYSQL database.

https://user-images.githubusercontent.com/87187220/133938624-b52ecb92-ebcd-48fb-b2f3-ffa84a370587.mp4

[PLACEMENT.MANAGEMENT (1).docx](https://github.com/Punitha-11/Final-Project-Placement-Management-System/files/7192684/PLACEMENT.MANAGEMENT.1.docx)
